// Same API in Express (run `npm install express` first). Not run in my sandbox.
const express = require("express");
const app = express();
app.use(express.json()); // middleware: parse JSON bodies
let todos = [{ id: 1, title: "Learn REST", done: false }];
let nextId = 2;

app.get("/todos", (req, res) => res.json(todos));
app.get("/todos/:id", (req, res) => {
  const t = todos.find((x) => x.id === Number(req.params.id));
  t ? res.json(t) : res.status(404).json({ error: "Not found" });
});
app.post("/todos", (req, res) => {
  if (!req.body.title) return res.status(400).json({ error: "title is required" });
  const t = { id: nextId++, title: req.body.title, done: false };
  todos.push(t); res.status(201).json(t);
});
app.put("/todos/:id", (req, res) => {
  const t = todos.find((x) => x.id === Number(req.params.id));
  if (!t) return res.status(404).json({ error: "Not found" });
  Object.assign(t, req.body, { id: t.id }); res.json(t);
});
app.delete("/todos/:id", (req, res) => {
  todos = todos.filter((x) => x.id !== Number(req.params.id));
  res.json({ deleted: Number(req.params.id) });
});
app.listen(4000, () => console.log("API running at http://localhost:4000"));
