// REST API with GET/POST/PUT/DELETE, in-memory data, built-in http only.
const http = require("http");
let todos = [{ id: 1, title: "Learn REST", done: false }];
let nextId = 2;

const send = (res, code, data) => {
  res.writeHead(code, { "Content-Type": "application/json" });
  res.end(JSON.stringify(data));
};

http.createServer((req, res) => {
  const match = req.url.match(/^\/todos(?:\/(\d+))?$/);
  if (!match) return send(res, 404, { error: "Not found" });
  const id = match[1] && Number(match[1]);
  let body = "";
  req.on("data", (c) => (body += c));
  req.on("end", () => {
    let data = {};
    try { data = body ? JSON.parse(body) : {}; } catch { return send(res, 400, { error: "Invalid JSON" }); }
    const item = todos.find((t) => t.id === id);
    if (req.method === "GET" && !id) return send(res, 200, todos);
    if (req.method === "GET") return item ? send(res, 200, item) : send(res, 404, { error: "Not found" });
    if (req.method === "POST" && !id) {
      if (!data.title) return send(res, 400, { error: "title is required" });
      const t = { id: nextId++, title: data.title, done: false };
      todos.push(t); return send(res, 201, t);
    }
    if (id && !item) return send(res, 404, { error: "Not found" });
    if (req.method === "PUT" && item) return send(res, 200, Object.assign(item, data, { id }));
    if (req.method === "DELETE" && item) { todos = todos.filter((t) => t.id !== id); return send(res, 200, { deleted: id }); }
    send(res, 405, { error: "Method not allowed" });
  });
}).listen(process.env.PORT || 4000, () => console.log("API running at http://localhost:4000"));
