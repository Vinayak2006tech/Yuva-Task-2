import { useState, useEffect } from "react";

function Counter() {
  const [count, setCount] = useState(0);
  useEffect(() => { document.title = `Count: ${count}`; }, [count]);
  return (
    <div>
      <h3>Counter (useState + useEffect)</h3>
      <button onClick={() => setCount(count - 1)}>-</button>
      <strong>{count}</strong>
      <button onClick={() => setCount(count + 1)}>+</button>
    </div>
  );
}

function Todos() {
  const [items, setItems] = useState([]);
  const [text, setText] = useState("");
  const add = () => {
    if (!text.trim()) return;
    setItems([...items, { id: Date.now(), text, done: false }]); // new array, no mutation
    setText("");
  };
  const toggle = (id) => setItems(items.map((i) => (i.id === id ? { ...i, done: !i.done } : i)));
  return (
    <div>
      <h3>Todos (props, state, lists and keys)</h3>
      <input value={text} onChange={(e) => setText(e.target.value)} placeholder="New task" />
      <button onClick={add}>Add</button>
      <ul>
        {items.map((i) => (
          <li key={i.id} className={i.done ? "done" : ""} onClick={() => toggle(i.id)}>{i.text}</li>
        ))}
      </ul>
      {items.length === 0 && <p>No tasks yet.</p>}
    </div>
  );
}

export default function App() {
  return <div className="card"><h2>React Mini App</h2><Counter /><Todos /></div>;
}
