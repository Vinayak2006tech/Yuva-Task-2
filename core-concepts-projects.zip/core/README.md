# Core Concepts and Skills - Mini Projects

| Folder | Concept | Run |
|---|---|---|
| `01-js-todo` | DOM, events, array methods (`filter`, `forEach`) | Open `index.html` in a browser |
| `02-react-app` | Components, props, state, hooks, lists and keys | `npm install` then `npm run dev` |
| `03-rest-api` | REST, HTTP methods, status codes, JSON | `node server.js` (Express version: `server-express.js`) |
| `04-mongodb-api` | Express + Mongoose schema and CRUD | Copy `.env.example` to `.env`, `npm install`, `npm start` |

Author: Vinayak Vaishy
