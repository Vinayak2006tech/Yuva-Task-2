// Express + Mongoose CRUD. Needs a MongoDB URI in .env (copy .env.example). Not run in my sandbox.
require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const Todo = require("./models/Todo");

const app = express();
app.use(express.json());

app.get("/todos", async (req, res) => res.json(await Todo.find()));
app.post("/todos", async (req, res) => {
  try { res.status(201).json(await Todo.create({ title: req.body.title })); }
  catch (err) { res.status(400).json({ error: err.message }); }
});
app.put("/todos/:id", async (req, res) => {
  const t = await Todo.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
  t ? res.json(t) : res.status(404).json({ error: "Not found" });
});
app.delete("/todos/:id", async (req, res) => {
  const t = await Todo.findByIdAndDelete(req.params.id);
  t ? res.json({ deleted: req.params.id }) : res.status(404).json({ error: "Not found" });
});

mongoose.connect(process.env.MONGO_URI)
  .then(() => app.listen(process.env.PORT || 4000, () => console.log("Connected to MongoDB, API running")))
  .catch((err) => console.error("DB connection failed:", err.message));
